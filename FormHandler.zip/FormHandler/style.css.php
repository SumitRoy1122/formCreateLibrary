<style type="text/css">
	/**********************************

Use: cmxform template

***********************************/
form.cmxform fieldset {
	margin-bottom: 10px;
}

form.cmxform legend {
	padding: 0 2px;
	font-weight: bold;
	_margin: 0 -7px; /* IE Win */
}

form.cmxform label {
	display: inline-block;
	line-height: 1.8;
	vertical-align: top;
	cursor: hand;
}

form.cmxform fieldset p {
	list-style: none;
	padding: 5px;
	margin: 0;
}

form.cmxform fieldset fieldset {
	border: none;
	margin: 3px 0 0;
}

form.cmxform fieldset fieldset legend {
	padding: 0 0 5px;
	font-weight: normal;
}

form.cmxform fieldset fieldset label {
	display: block;
	width: auto;
}

form.cmxform label { width: 100px; } /* Width of labels */
form.cmxform fieldset fieldset label { margin-left: 103px; } /* Width plus 3 (html space) */
form.cmxform label.error {
	margin-left: 103px;
	width: 220px;
}

form.cmxform input.submit {
	margin-left: 103px;
}

/*\*//*/ form.cmxform legend { display: inline-block; } /* IE Mac legend fix */

body, div { font-family: 'lucida grande', helvetica, verdana, arial, sans-serif }
body { margin: 0; padding: 0; font-size: small; color: #333 }
h1, h2 { font-family: 'trebuchet ms', verdana, arial; padding: 10px; margin: 0 }
h1 { font-size: large }
#main { padding: 1em; }
#banner { padding: 15px; background-color: #06b; color: white; font-size: large; border-bottom: 1px solid #ccc;
    background: url(../images/bg.gif) repeat-x; text-align: center }
#banner a { color: white; }
	
p { margin: 10px 0; }

li { margin-left: 10px; }

h3 { margin: 1em 0 0; }

h1 { font-size: 2em; }
h2 { font-size: 1.8em; }
h3 { font-size: 1.6em; }
h4 { font-size: 1.4em; }
h5 { font-size: 1.2em; }

/**********************************

Use: Reset Styles for all browsers

***********************************/
	
body, p, blockquote {
	margin: 0;
	padding: 0;
}

a img, iframe { border: none; }
	
/* Headers
------------------------------*/

h1, h2, h3, h4, h5, h6 {
	margin: 0;
	padding: 0;
	font-size: 100%;
}
	
/* Lists
------------------------------*/
	
ul, ol, dl, li, dt, dd {
	margin: 0;
	padding: 0;
}
	
/* Links
------------------------------*/

a, a:link {}
a:visited {}
a:hover {}
a:active {}

/* Forms
------------------------------*/

form, fieldset {
	margin: 0;
	padding: 0;
}
	
fieldset { border: 1px solid #000; }

legend {
	padding: 0;
	color: #000;
}

input, textarea, select {
	margin: 0;
	padding: 1px;
	font-size: 100%;
	font-family: inherit;
}
	
select { padding: 0; }
/**********************************

Name: cmxform Styles

***********************************/
form.cmxform {
	width: 370px;
	font-size: 1.0em;
	color: #333;
}

form.cmxform legend {
	padding-left: 0;
}

form.cmxform legend, form.cmxform label {
	color: #333;
}

form.cmxform fieldset {
	border: none;
	border-top: 1px solid #C9DCA6;
	background: url(../images/cmxform-fieldset.gif) left bottom repeat-x;
	background-color: #F8FDEF;
}

form.cmxform fieldset fieldset {
	background: none;
}

form.cmxform fieldset p, form.cmxform fieldset fieldset {
	padding: 5px 10px 7px;
	background: url(../images/cmxform-divider.gif) left bottom repeat-x;
}

form.cmxform label.error, label.error {
	/* remove the next line when you have trouble in IE6 with labels in list */
	color: red;
	font-style: italic
}
div.error { display: none; }
input {	border: 1px solid black; }
input.checkbox { border: none }
input:focus { border: 1px dotted black; }
input.error { border: 1px dotted red; }
form.cmxform .gray * { color: gray; }
</style>